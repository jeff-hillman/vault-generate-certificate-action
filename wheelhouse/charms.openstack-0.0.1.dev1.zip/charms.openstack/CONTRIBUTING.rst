The source repository for this project can be found at:

   https://opendev.org/openstack/charms.openstack

Pull requests submitted through GitHub are not monitored.

To start contributing to OpenStack, follow the steps in the contribution guide
to set up and use Gerrit:

   https://docs.openstack.org/contributors/code-and-documentation/quick-start.html

Bugs should be filed on Launchpad:

   https://bugs.launchpad.net/charms.openstack

Developers should also join the discussion on the mailing list, at:

  https://lists.ubuntu.com/openstack-charmers
  http://lists.openstack.org/cgi-bin/mailman/listinfo/openstack-discuss

or join the IRC channel on

  #openstack-charms on OFTC (irc.oftc.net)
