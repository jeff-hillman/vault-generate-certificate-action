# this is a generated file

version = '1.1.0'
