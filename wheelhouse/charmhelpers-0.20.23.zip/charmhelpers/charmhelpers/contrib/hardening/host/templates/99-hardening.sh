TMOUT={{ tmout }}
readonly TMOUT
export TMOUT

readonly HISTFILE
