charmhelpers.core.strutils
============================

.. automodule:: charmhelpers.core.strutils
    :members:
    :undoc-members:
    :show-inheritance:
