#!/usr/bin/env bash

pip install pip==20.2.3
pip "$@"
