def create_lb(request):
    return "dummy-lb"
