Class Registry
==============

.. automodule:: marshmallow.class_registry
    :members:
